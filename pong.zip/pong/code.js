var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["2467a9d0-c726-4934-8543-8fd47da06b33","89ce27e8-44c5-4f21-9108-2c5bc29fbaab","06f95599-d59a-4f7e-8fd2-b8d2199de167","af6abee0-ad58-4f48-b002-c6c4e304024f","e15cc1ab-b3ae-4e41-8033-3f18d1b09d2a"],"propsByKey":{"2467a9d0-c726-4934-8543-8fd47da06b33":{"name":"Pelotita ","sourceUrl":null,"frameSize":{"x":393,"y":394},"frameCount":4,"looping":true,"frameDelay":20,"version":"u.RVhiu7Ruj4mq3TJyM3A3Ultl1619uv","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":786,"y":788},"rootRelativePath":"assets/2467a9d0-c726-4934-8543-8fd47da06b33.png"},"89ce27e8-44c5-4f21-9108-2c5bc29fbaab":{"name":"rojo","sourceUrl":null,"frameSize":{"x":32,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"oGTn3uLJHbiRlGdmCW2KGJ6AETQCNF22","loadedFromSource":true,"saved":true,"sourceSize":{"x":32,"y":50},"rootRelativePath":"assets/89ce27e8-44c5-4f21-9108-2c5bc29fbaab.png"},"06f95599-d59a-4f7e-8fd2-b8d2199de167":{"name":"muerto rojo","sourceUrl":null,"frameSize":{"x":61,"y":22},"frameCount":1,"looping":true,"frameDelay":12,"version":"r4HHaGvlsf32AaCFOkIqzn2aFvEJD881","loadedFromSource":true,"saved":true,"sourceSize":{"x":61,"y":22},"rootRelativePath":"assets/06f95599-d59a-4f7e-8fd2-b8d2199de167.png"},"af6abee0-ad58-4f48-b002-c6c4e304024f":{"name":"azul","sourceUrl":null,"frameSize":{"x":28,"y":53},"frameCount":1,"looping":true,"frameDelay":12,"version":"xT1nn8unalnQtM5i7Ozt6ulPWlLYk5oR","loadedFromSource":true,"saved":true,"sourceSize":{"x":28,"y":53},"rootRelativePath":"assets/af6abee0-ad58-4f48-b002-c6c4e304024f.png"},"e15cc1ab-b3ae-4e41-8033-3f18d1b09d2a":{"name":"muerto azul","sourceUrl":null,"frameSize":{"x":53,"y":22},"frameCount":1,"looping":true,"frameDelay":12,"version":"L2SNT1D3K2S2CrwRSyT9ieJNFDXMPGQ8","loadedFromSource":true,"saved":true,"sourceSize":{"x":53,"y":22},"rootRelativePath":"assets/e15cc1ab-b3ae-4e41-8033-3f18d1b09d2a.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var PuntosAzul = 0;
var PuntosRojo = 0;
var Raqueta = createSprite(20, 200, 20, 100);
Raqueta.shapeColor = "Blue";
Raqueta.setAnimation("azul");
var Raqueta2 = createSprite(380, 200, 20, 100);
Raqueta2.shapeColor = "Red";
Raqueta2.setAnimation("rojo");
var Pelota = createSprite(200, 200, 35, 35);
Pelota.shapeColor = "Cyan";
Pelota.setAnimation("Pelotita ");
Pelota.scale = 0.07;
createEdgeSprites();
function draw() {
  Pelota.bounceOff(Raqueta2);
  Pelota.bounceOff(Raqueta);
  //Raqueta.collide(topEdge);
  //Raqueta.collide(bottomEdge);
  //Raqueta2.collide(edges);
  //Raqueta2.collide(edges);
  background("white");
  textSize(15);
  fill("blue");
  text("Puntos Azul  "+PuntosAzul, 50, 20);
  fill("red");
  text("Puntos Rojo  "+PuntosRojo, 250, 20);
  for (var v = 0; v < 400; v=v+20) {
    line(200, v, 200, v+10);
  }
  drawSprites();
  if (keyDown("w")) {
    Raqueta.y = Raqueta.y-10;
  }
  if (keyDown("s")) {
  Raqueta.y = Raqueta.y+10;
  }
 Raqueta.y = Pelota.y
  if (keyDown("space")) {
    Pelota.velocityX = -5.5;
    Pelota.velocityY = 7.5;
    Raqueta.setAnimation("azul");
    Raqueta2.setAnimation("rojo");
  }
  Raqueta2.y = World.mouseY;
  if (keyDown("r")) {
   Pelota.x=200;
   Pelota.y=200;
   Pelota.velocityX = 0.0;
   Pelota.velocityY = 0.0;
 }
 if (keyDown("p")) {
   Pelota.velocityX = 0.0;
   Pelota.velocityY = 0.0;
 }
  if (Pelota.isTouching(leftEdge)){
    Raqueta.setAnimation("muerto azul");
    PuntosRojo = PuntosRojo+1;
    playSound("assets/category_alerts/airy_bell_notification.mp3", false);
  }
  if (Pelota.isTouching(rightEdge)){
    Raqueta2.setAnimation("muerto rojo");
    PuntosAzul = PuntosAzul +1;
    playSound("assets/category_alerts/airy_bell_notification.mp3", false);
  }
 
  if (Pelota.isTouching(leftEdge) || Pelota.isTouching(rightEdge)) {
   Pelota.x=200
   Pelota.y=200
   Pelota.velocityX = 0.0;
   Pelota.velocityY = 0.0;
   Raqueta.setAnimation("azul");
   Raqueta2.setAnimation("rojo");
 }
  if (Pelota.bounceOff(topEdge) ||  Pelota.bounceOff(bottomEdge)) {
    playSound("assets/default.mp3", false);
  }
  if (PuntosAzul >= 5) {
    PuntosAzul = 0;
    PuntosRojo = 0;
    //playSound("assets/category_bell/vibrant_game_star_burst_3.mp3", false);
    //text("Ganó Azul", 200, 200);
  }
  if (PuntosRojo >= 5) {
    PuntosAzul = 0;
    PuntosRojo = 0;
    //playSound("assets/category_bell/vibrant_game_star_burst_3.mp3", false);
    //text("Ganó Rojo", 200, 200);
  }
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
